<?php
	switch ($_REQUEST["acao"]) {
		case 'cadastrar':
			$atendente  = $_POST["atendente_id_atendente"];
			$aluno      = $_POST["aluno_id_aluno"];
			$livro      = $_POST["livro_id_livro"];
			$emprestimo = $_POST["data_emprestimo"];
			$entrega    = $_POST["data_entrega"];

			$sql = "INSERT INTO reserva (atendente_id_atendente, aluno_id_aluno, livro_id_livro, data_emprestimo, data_entrega)
					VALUES ({$atendente},'{$aluno}','{$livro}','{$emprestimo}','{$entrega}')";

			$res = $conn->query($sql) or die($conn->error);

			if($res==true){
				print "<script>alert('Cadastrou com sucesso!');</script>";
				print "<script>location.href='?page=listar-reserva';</script>";
			}else{
				print "<script>alert('Não foi possível cadastrar!');</script>";
				print "<script>location.href='?page=listar-reserva';</script>";
			}
			break;
		
		case 'editar':
			$atendente  = $_POST["atendente_id_atendente"];
			$aluno      = $_POST["aluno_id_aluno"];
			$livro      = $_POST["livro_id_livro"];
			$emprestimo = $_POST["data_emprestimo"];
			$entrega    = $_POST["data_entrega"];

			$sql = "UPDATE reserva SET atendente_id_atendente={$atendente}, aluno_id_aluno='{$aluno}', livro_id_livro='{$livro}', data_emprestimo='{$emprestimo}', data_entrega='{$entrega}' WHERE id_reserva=".$_POST["id_reserva"];

			$res = $conn->query($sql) or die($conn->error);

			if($res==true){
				print "<script>alert('Editou com sucesso!');</script>";
				print "<script>location.href='?page=listar-reserva';</script>";
			}else{
				print "<script>alert('Não foi possível editar!');</script>";
				print "<script>location.href='?page=listar-reserva';</script>";
			}
			break;

		case 'excluir':
			$sql = "DELETE FROM reserva WHERE id_reserva=".$_REQUEST["id_reserva"];

			$res = $conn->query($sql) or die($conn->error);

			if($res==true){
				print "<script>alert('Excluiu com sucesso!');</script>";
				print "<script>location.href='?page=listar-reserva';</script>";
			}else{
				print "<script>alert('Não foi possível excluir!');</script>";
				print "<script>location.href='?page=listar-reserva';</script>";
			}
			break;
	}